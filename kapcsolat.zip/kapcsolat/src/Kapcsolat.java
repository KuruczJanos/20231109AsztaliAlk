import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Kapcsolat {

    public void connect() {
        try {
            tryConnect();
        } catch (SQLException e) {
            System.err.println("Hiba! A kapcsolat sikerteln");
            System.err.println(e.getMessage());
        }
    }
    public void tryConnect() throws SQLException {
        String url = "jdbc:mariadb://localhost:3306/emp";
        Connection conn = null;

        conn = DriverManager.getConnection(url);
    }
}
